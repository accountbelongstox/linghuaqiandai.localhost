<style type="text/css">
/*管理员CSS*/
#<?php echo $module['module_name'];?> {
}

#<?php echo $module['module_name'];?>_html {
	
}
.<?php echo $module['module_name'];?> {
}

.<?php echo $module['module_name'];?>_html {
	
}
.<?php echo $module['module_name'];?>_html {
	
}
.<?php echo $module['module_name'];?>_html {
	
}
.<?php echo $module['module_name'];?>_html {
	
}
.<?php echo $module['module_name'];?>_html {
	
}
.<?php echo $module['module_name'];?>_html {
	
}
.<?php echo $module['module_name'];?>_html {
	
}
.<?php echo $module['module_name'];?>_html {
	
}
.<?php echo $module['module_name'];?>_html {
	
}
.<?php echo $module['module_name'];?>_html {
	
}
.<?php echo $module['module_name'];?>_html {
	
}
.<?php echo $module['module_name'];?>_html {
	
}
.<?php echo $module['module_name'];?>_html {
	
}
.<?php echo $module['module_name'];?>_html {
	
}
.<?php echo $module['module_name'];?>_html {
	
}
.<?php echo $module['module_name'];?>_html {
	
}

</style>